#!/usr/bin/env python3

from bottle import get, post, request, response, static_file, default_app
from AlphaBot import AlphaBot
from config import BOT_TOKEN, CHAT_ID

import threading
import requests
import io
import RPi.GPIO as GPIO

from picamera2 import Picamera2
from picamera2.encoders import JpegEncoder
from picamera2.outputs import FileOutput

# ===== MJPEG stream buffer =====
class StreamingOutput(io.BufferedIOBase):
    def __init__(self):
        super().__init__()
        self.frame = None
        self.condition = threading.Condition()

    def write(self, buf):
        with self.condition:
            self.frame = buf
            self.condition.notify_all()

    def flush(self):
        pass

output = StreamingOutput()
picam2 = None
CAMERA_OK = False

try:
    picam2 = Picamera2()
    video_config = picam2.create_video_configuration(main={"size": (640, 480)})
    picam2.configure(video_config)
    picam2.start_recording(JpegEncoder(), FileOutput(output))
    CAMERA_OK = True
    print("[CAM] Camera started.")
except Exception as e:
    print("[CAM] Camera init error:", e)
    picam2 = None
    CAMERA_OK = False


# ===== Robot =====
car = AlphaBot()
cur_speed = 50  # default PWM (20–100)

# ===== Servo (pan) =====
SERVO_PIN = 27  # BCM pin cho servo (đổi nếu bạn cắm vào chân khác)
GPIO.setmode(GPIO.BCM)
GPIO.setup(SERVO_PIN, GPIO.OUT)
servo_pwm = GPIO.PWM(SERVO_PIN, 50)  # 50Hz cho servo
servo_pwm.start(0)
current_pan = 90  # bắt đầu ở giữa (90 độ)

def set_servo_angle(angle):
    global current_pan
    angle = max(0, min(180, int(angle)))
    duty = 2.5 + (angle / 180.0) * 10.0  # khoảng 2.5–12.5% duty
    servo_pwm.ChangeDutyCycle(duty)
    current_pan = angle
    print("[SERVO] set angle ->", angle)

# ===== Snapshot (để preview/gửi sau) =====
_last_capture = None
_last_lock = threading.Lock()

# ===== Routes =====
@get("/")
def index():
    return static_file("index.html", root=".")

@get("/video")
def video():
    if not CAMERA_OK:
        response.status = 500
        return "Camera not available"

    response.content_type = "multipart/x-mixed-replace; boundary=frame"

    def generate():
        while True:
            with output.condition:
                output.condition.wait()
                frame = output.frame
            if not frame:
                continue
            yield (b"--frame\r\n"
                   b"Content-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
    return generate()

@post("/motor")
def motor_cmd():
    global cur_speed
    code = request.forms.get("code")
    speed = request.forms.get("speed")

    if speed:
        try:
            cur_speed = max(20, min(100, int(speed)))
            print("[MOTOR] Speed ->", cur_speed)
        except Exception as e:
            print("[MOTOR] speed parse error:", e)

    if not code:
        return "OK"

    if code == "forward":
        car.setPWMA(cur_speed); car.setPWMB(cur_speed); car.forward();  print("[MOTOR] forward")
    elif code == "backward":
        car.setPWMA(cur_speed); car.setPWMB(cur_speed); car.backward(); print("[MOTOR] backward")
    elif code == "turnleft":
        car.setPWMA(cur_speed); car.setPWMB(cur_speed); car.left();     print("[MOTOR] turnleft")
    elif code == "turnright":
        car.setPWMA(cur_speed); car.setPWMB(cur_speed); car.right();    print("[MOTOR] turnright")
    elif code == "stop":
        car.stop(); print("[MOTOR] stop")

    return "OK"

@post("/servo")
def servo_cmd():
    global current_pan
    pan  = request.forms.get("pan")
    tilt = request.forms.get("tilt")

    # pan: -1, 0, +1 từ web (nút trái/phải/center)
    if pan not in (None, ""):
        try:
            step = int(pan)
        except ValueError:
            step = 0

        if step == 0:
            # đưa về chính giữa
            set_servo_angle(90)
        else:
            # mỗi lần nhấn, quay 5 độ
            set_servo_angle(current_pan + step * 5)

    # tilt hiện tại chỉ log (nếu sau này bạn gắn thêm servo thứ 2 thì ta xử lý tiếp)
    if tilt not in (None, ""):
        print("[SERVO] TILT step ->", tilt)

    return "OK"

def send_to_telegram(image_bytes: bytes):
    if not BOT_TOKEN: return False, "Thiếu BOT_TOKEN trong config.py"
    if not CHAT_ID:   return False, "Thiếu CHAT_ID trong config.py"
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"
    files = { "photo": ("alphabot.jpg", image_bytes, "image/jpeg") }
    data  = { "chat_id": CHAT_ID, "caption": "📸 Ảnh chụp từ AlphaBot" }
    try:
        r = requests.post(url, data=data, files=files, timeout=10)
        print("[TG]", r.status_code, r.text[:200])
        return (r.status_code == 200), ( "Đã gửi ảnh lên Telegram." if r.status_code == 200 else r.text )
    except Exception as e:
        return False, f"Lỗi kết nối: {e}"

@get("/preview.jpg")
def preview_jpg():
    global _last_capture
    with _last_lock:
        data = _last_capture
    if not data:
        response.status = 404
        return "No capture yet"
    response.content_type = "image/jpeg"
    return data

@post("/snapshot")
def snapshot():
    global _last_capture
    if not CAMERA_OK:
        response.status = 500
        return "Camera không sẵn sàng."
    with output.condition:
        frame = output.frame
    if not frame:
        response.status = 500
        return "Không lấy được frame từ camera."
    with _last_lock:
        _last_capture = bytes(frame)
    return "SNAP_OK"

@post("/send_last_capture")
def send_last_capture():
    with _last_lock:
        data = _last_capture
    if not data:
        response.status = 400
        return "Chưa có ảnh để gửi. Hãy nhấn Chụp trước."
    ok, msg = send_to_telegram(data)
    if ok: return msg
    response.status = 500
    return msg

# ===== Threaded server (tránh bị treo khi stream) =====
if __name__ == "__main__":
    from wsgiref.simple_server import make_server, WSGIServer
    from socketserver import ThreadingMixIn
    class ThreadingWSGIServer(ThreadingMixIn, WSGIServer):
        daemon_threads = True
    try:
        app = default_app()
        httpd = make_server("0.0.0.0", 8000, app, server_class=ThreadingWSGIServer)
        print("[HTTP] Threaded server on http://0.0.0.0:8000")
        httpd.serve_forever()
    finally:
        try:
            if CAMERA_OK and picam2 is not None:
                picam2.stop_recording()
                picam2.close()
        except Exception:
            pass
        try:
            servo_pwm.stop()
        except Exception:
            pass
        car.stop()
        try:
            GPIO.cleanup()
        except Exception:
            pass
