# motor_direct_test.py (BCM)
import RPi.GPIO as GPIO, time
IN1, IN2, ENA = 12, 13, 6
IN3, IN4, ENB = 20, 21, 26
GPIO.setmode(GPIO.BCM); GPIO.setwarnings(False)
for p in (IN1,IN2,ENA,IN3,IN4,ENB):
    GPIO.setup(p, GPIO.OUT); GPIO.output(p, GPIO.LOW)

GPIO.output(ENA, GPIO.HIGH); GPIO.output(ENB, GPIO.HIGH)

def drive(a1,a2,b1,b2,t=1.0,msg=""):
    print(msg)
    GPIO.output(IN1,a1); GPIO.output(IN2,a2)
    GPIO.output(IN3,b1); GPIO.output(IN4,b2)
    time.sleep(t)

try:
    drive(1,0,0,1,1.2,"Forward")
    drive(0,1,1,0,1.2,"Backward")
    drive(0,1,0,1,0.8,"Spin Left")
    drive(1,0,1,0,0.8,"Spin Right")
finally:
    for p in (IN1,IN2,ENA,IN3,IN4,ENB): GPIO.output(p, GPIO.LOW)
    GPIO.cleanup()