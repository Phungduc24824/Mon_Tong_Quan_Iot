#!/usr/bin/env python3
from picamera2 import Picamera2, Preview
import time

# In case bạn muốn xem Pi phát hiện được mấy camera
print("Cameras:", Picamera2.global_camera_info())

picam2 = Picamera2()
# Hiển thị cửa sổ preview. Nếu lỗi QTGL, đổi sang Preview.QT
picam2.start_preview(Preview.QTGL)

# Cấu hình preview đơn giản
picam2.configure(picam2.create_preview_configuration(main={"size": (640, 480)}))
picam2.start()

print("Preview running. Nhấn Ctrl+C để thoát.")
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    pass
finally:
    picam2.stop()
    picam2.close()