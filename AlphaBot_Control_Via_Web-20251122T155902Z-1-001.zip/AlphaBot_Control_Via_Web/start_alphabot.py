#!/usr/bin/env python3
import subprocess
import time
import os
import signal

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE_DIR)

# Chạy cam_stream.py
cam = subprocess.Popen(
    ["python3", "cam_stream.py"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE
)

# Đợi 3s cho camera lên (tránh web gọi stream quá sớm)
time.sleep(3)

# Chạy main.py (web + motor + servo)
web = subprocess.Popen(
    ["python3", "main.py"],
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE
)

def shutdown():
    # Tắt web trước
    try:
        web.terminate()
    except Exception:
        pass
    try:
        web.wait(timeout=5)
    except Exception:
        try:
            web.kill()
        except Exception:
            pass

    # Tắt cam
    try:
        cam.terminate()
    except Exception:
        pass
    try:
        cam.wait(timeout=5)
    except Exception:
        try:
            cam.kill()
        except Exception:
            pass

try:
    # Đợi web server kết thúc (nếu lỗi, service sẽ restart)
    web.wait()
finally:
    shutdown()