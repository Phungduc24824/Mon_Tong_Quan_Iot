#!/usr/bin/env python3
from picamera2 import Picamera2
from libcamera import Transform
import cv2, numpy as np, threading, http.server, socketserver, time

CFG_PATH = "models/yolov3-tiny.cfg"
WEIGHTS_PATH = "models/yolov3-tiny.weights"

print("Loading YOLOv3-tiny (people counter)...")
net = cv2.dnn.readNetFromDarknet(CFG_PATH, WEIGHTS_PATH)
net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)

model = cv2.dnn_DetectionModel(net)
model.setInputParams(scale=1/255.0, size=(320, 320), swapRB=True)

# Camera: nhỏ lại cho nhanh nhưng vẫn xem được
picam2 = Picamera2()
picam2.configure(
    picam2.create_video_configuration(
        main={"size": (320, 240)},
        transform=Transform(hflip=0, vflip=0)
    )
)
picam2.start()
time.sleep(1)

print("Camera started.")

class State:
    def __init__(self):
        self.frame = None
        self.cond = threading.Condition()

state = State()

def loop():
    last_boxes = []
    last_scores = []
    frame_idx = 0

    while True:
        frame = picam2.capture_array()
        if frame is None:
            continue

        # BGRA -> BGR nếu cần
        if len(frame.shape) == 3 and frame.shape[2] == 4:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)

        frame_idx += 1

        # Chỉ chạy YOLO mỗi 3 frame để giảm tải
        if frame_idx % 3 == 0:
            try:
                classes, scores, boxes = model.detect(
                    frame, confThreshold=0.5, nmsThreshold=0.4
                )
            except cv2.error as e:
                print("DNN error:", e)
                classes, scores, boxes = None, None, None

            last_boxes = []
            last_scores = []
            if classes is not None and len(classes) > 0:
                for cls, sc, box in zip(classes.flatten(), scores.flatten(), boxes):
                    if cls == 0:  # person
                        last_boxes.append(box)
                        last_scores.append(sc)

        # Vẽ từ last_boxes (kể cả frame không detect mới)
        people = 0
        for (box, sc) in zip(last_boxes, last_scores):
            x, y, w, h = box
            people += 1
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0,255,0), 2)
            cv2.putText(frame, f"{sc*100:.0f}%", (x, y-5),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255,0), 1)

        cv2.putText(frame, f"People: {people}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,255,255), 2)

        ok, jpg = cv2.imencode(".jpg", frame)
        if not ok:
            continue

        with state.cond:
            state.frame = jpg.tobytes()
            state.cond.notify_all()

# Thread xử lý
threading.Thread(target=loop, daemon=True).start()

PAGE = b"""<!doctype html>
<title>People Counter</title>
<h3>Pi Camera - People Counter (YOLOv3-tiny, optimized)</h3>
<img src="/stream.mjpg" style="max-width:100%;border:1px solid #ddd;border-radius:8px"/>
"""
class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type","text/html")
            self.end_headers()
            self.wfile.write(PAGE)
        elif self.path == "/stream.mjpg":
            self.send_response(200)
            self.send_header("Cache-Control","no-cache, private")
            self.send_header("Pragma","no-cache")
            self.send_header("Content-Type","multipart/x-mixed-replace; boundary=FRAME")
            self.end_headers()
            try:
                while True:
                    with state.cond:
                        state.cond.wait()
                        frame = state.frame
                    if not frame:
                        continue
                    self.wfile.write(
                        b"--FRAME\r\n"
                        b"Content-Type: image/jpeg\r\n"
                        b"Content-Length: " + str(len(frame)).encode() +
                        b"\r\n\r\n" + frame + b"\r\n"
                    )
            except (BrokenPipeError, ConnectionResetError):
                pass
        else:
            self.send_error(404)

class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True

if __name__ == "__main__":
    addr = ("0.0.0.0", 8090)
    httpd = ThreadedHTTPServer(addr, Handler)
    print(f"People counter: http://<IP-Pi>:{addr[1]}/")
    try:
        httpd.serve_forever()
    finally:
        picam2.stop()
