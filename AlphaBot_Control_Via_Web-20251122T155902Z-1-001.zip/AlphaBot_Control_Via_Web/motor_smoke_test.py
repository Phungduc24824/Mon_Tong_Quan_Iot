# motor_smoke_test.py
import time
from AlphaBot import AlphaBot

bot = AlphaBot()              # dùng BCM: IN1=13, IN2=12, ENA=6, IN3=21, IN4=20, ENB=26
print("Tiến nhẹ 1s...")
bot.setMotor(50, 50); time.sleep(1)

print("Lùi nhẹ 1s...")
bot.setMotor(-50, -50); time.sleep(1)

print("Quay trái tại chỗ 0.6s...")
bot.setMotor(-60, 60); time.sleep(0.6)

print("Quay phải tại chỗ 0.6s...")
bot.setMotor(60, -60); time.sleep(0.6)

bot.stop(); print("Xong.")