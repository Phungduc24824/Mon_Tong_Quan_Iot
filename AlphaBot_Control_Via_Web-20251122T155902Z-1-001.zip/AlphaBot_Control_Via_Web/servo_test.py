import RPi.GPIO as GPIO
from time import sleep

# Chân điều khiển servo trên AlphaBot (theo PIVietnam)
SERVO_PAN = 27   # xoay trái/phải
SERVO_TILT = 22  # ngẩng lên/hạ xuống

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

GPIO.setup(SERVO_PAN, GPIO.OUT)
GPIO.setup(SERVO_TILT, GPIO.OUT)

pan = GPIO.PWM(SERVO_PAN, 50)   # 50Hz cho servo
tilt = GPIO.PWM(SERVO_TILT, 50)

pan.start(0)
tilt.start(0)

def angle_to_duty(angle):
    # Giới hạn 0-180 độ, công thức tương tự code PIVietnam
    angle = max(0, min(180, float(angle)))
    return 2.0 + (angle / 18.0)  # ~2-12% duty

def set_pan(angle):
    dc = angle_to_duty(angle)
    pan.ChangeDutyCycle(dc)
    sleep(0.3)
    pan.ChangeDutyCycle(0)

def set_tilt(angle):
    dc = angle_to_duty(angle)
    tilt.ChangeDutyCycle(dc)
    sleep(0.3)
    tilt.ChangeDutyCycle(0)

try:
    print("Center...")
    set_pan(90); set_tilt(90)

    print("Pan left")
    set_pan(30)
    print("Pan right")
    set_pan(150)

    print("Tilt up")
    set_tilt(60)
    print("Tilt down")
    set_tilt(120)

    print("Back to center")
    set_pan(90); set_tilt(90)
finally:
    pan.stop()
    tilt.stop()
    GPIO.cleanup()