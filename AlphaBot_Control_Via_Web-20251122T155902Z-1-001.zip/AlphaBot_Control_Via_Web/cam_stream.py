# cam_stream.py — Picamera2 -> HTTP MJPEG (multipart)
# Truy cập: http://<IP-Pi>:8081/  hoặc /stream.mjpg

from picamera2 import Picamera2
from picamera2.encoders import JpegEncoder
from picamera2.outputs import FileOutput
from libcamera import Transform
import io, threading, http.server, socketserver

print("=== cam_stream.py (8MP MJPEG stream for Pi Camera v2) ===")

class StreamingOutput(io.BufferedIOBase):
    def __init__(self):
        self.frame = None
        self.condition = threading.Condition()

    def write(self, buf):
        # Với JpegEncoder, mỗi lần write là 1 frame JPEG hoàn chỉnh
        with self.condition:
            self.frame = buf
            self.condition.notify_all()
        return len(buf)


output = StreamingOutput()

# ========== CẤU HÌNH CAMERA ==========
picam2 = Picamera2()

# Pi Camera v2.1 (IMX219) hỗ trợ tối đa 3280x2464 @ ~15fps.
# Dùng full-res để có hình sắc nét nhất, chấp nhận tải CPU & băng thông lớn.
video_config = picam2.create_video_configuration(
    main={"size": (1280, 720)},      # FULL 8MP
    transform=Transform(hflip=0, vflip=0)
)

picam2.configure(video_config)

# Encoder JPEG chất lượng cao
encoder = JpegEncoder(q=80)  # tăng q nếu muốn nét hơn nữa, giảm nếu muốn nhẹ hơn

# Bắt đầu ghi: output phải là BufferedIOBase
picam2.start_recording(encoder, FileOutput(output))

PAGE = b"""<!doctype html><title>Pi Cam</title>
<h3>Pi Camera Stream (8MP)</h3>
<img src="/stream.mjpg" style="max-width:100%;border:1px solid #ddd;border-radius:8px"/>
"""

class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/':
            self.send_response(200)
            self.send_header('Content-Type','text/html')
            self.end_headers()
            self.wfile.write(PAGE)

        elif self.path == '/stream.mjpg':
            self.send_response(200)
            self.send_header('Cache-Control','no-cache, private')
            self.send_header('Pragma','no-cache')
            self.send_header('Content-Type','multipart/x-mixed-replace; boundary=FRAME')
            self.end_headers()
            try:
                while True:
                    with output.condition:
                        output.condition.wait()
                        frame = output.frame
                    if not frame:
                        continue
                    self.wfile.write(
                        b'--FRAME\r\n'
                        b'Content-Type: image/jpeg\r\n'
                        b'Content-Length: ' + str(len(frame)).encode() + b'\r\n\r\n' +
                        frame + b'\r\n'
                    )
            except (BrokenPipeError, ConnectionResetError):
                # Client đóng tab / mất kết nối
                pass
        else:
            self.send_error(404)


class ThreadedHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True


try:
    addr = ('0.0.0.0', 8081)
    httpd = ThreadedHTTPServer(addr, Handler)
    print(f"Streaming: http://<IP-Pi>:{addr[1]}/  (Ctrl+C de dung)")
    httpd.serve_forever()
finally:
    try:
        picam2.stop_recording()
    except Exception:
        pass
