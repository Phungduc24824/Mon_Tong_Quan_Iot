''' + cam_msg + '''
    <img id="video" src="/video" />

    <div class="controls">
        <div>
            <button onclick="cmd('forward')">↑</button>
        </div>
        <div>
            <button onclick="cmd('left')">←</button>
            <button onclick="cmd('stop')">■</button>
            <button onclick="cmd('right')">→</button>
        </div>
        <div>
            <button onclick="cmd('backward')">↓</button>
        </div>
    </div>

    <div>
        <button id="capture-btn" onclick="capture()">📸 Chụp &amp; gửi Telegram</button>
    </div>

<script>
function cmd(action) {
    fetch('/cmd/' + action, { method: 'POST' });
}

function capture() {
    fetch('/capture', { method: 'POST' })
        .then(r => r.text())
        .then(t => alert(t))
        .catch(e => alert('Lỗi: ' + e));
}
</script>
</body>
</html>
'''


# ---------- Stream MJPEG lên /video ----------

@app.route('/video')
def video():
    if not CAMERA_OK:
        response.status = 500
        return "Camera not available"

    response.content_type = 'multipart/x-mixed-replace; boundary=frame'

    def generate():
        while True:
            with output.condition:
                output.condition.wait()
                frame = output.frame
            if not frame:
                continue
            yield (
                b'--frame\r\n'
                b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n'
            )

    return generate()


# ---------- API điều khiển xe ----------

@app.post('/cmd/<action>')
def cmd(action):
    if action == 'forward':
        Ab.forward()
    elif action == 'backward':
        Ab.backward()
    elif action == 'left':
        Ab.left()
    elif action == 'right':
        Ab.right()
    elif action == 'stop':
        Ab.stop()
    return 'OK'


# ---------- Hàm gửi ảnh lên Telegram (có log) ----------

def send_to_telegram(image_bytes):
    if not BOT_TOKEN:
        print("[TG] Thiếu BOT_TOKEN trong config.py")
        return False, 'Thiếu BOT_TOKEN trong config.py'
    if not CHAT_ID:
        print("[TG] Thiếu CHAT_ID trong config.py")
        return False, 'Thiếu CHAT_ID trong config.py'

    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendPhoto"
    files = {
        'photo': ('alphabot.jpg', image_bytes, 'image/jpeg')
    }
    data = {
        'chat_id': CHAT_ID,
        'caption': '📸 Ảnh chụp từ AlphaBot'
    }

    try:
        r = requests.post(url, data=data, files=files, timeout=10)
        print("[TG] Status:", r.status_code)
        print("[TG] Response:", r.text)
        if r.status_code == 200:
            return True, 'Đã chụp và gửi ảnh lên Telegram.'
        else:
            return False, f'Lỗi Telegram: {r.text}'
    except Exception as e:
        print("[TG] Exception:", e)
        return False, f'Lỗi kết nối: {e}'


# ---------- API /capture: chụp frame hiện tại & gửi ----------

@app.post('/capture')
def capture():
if not CAMERA_OK:
        response.status = 500
        return 'Camera không sẵn sàng.'

    with output.condition:
        frame = output.frame

    if not frame:
        print("[CAPTURE] frame = None")
        response.status = 500
        return 'Không lấy được frame từ camera.'

    print(f"[CAPTURE] Đã lấy frame, kích thước {len(frame)} bytes")
    ok, msg = send_to_telegram(frame)
    print("[CAPTURE]", msg)

    if ok:
        return msg
    else:
        response.status = 500
        return msg


# ---------- Chạy server ----------

if __name__ == '__main__':
    try:
        run(app, host='0.0.0.0', port=8000, debug=False, reloader=False)
    finally:
        try:
            if CAMERA_OK and picam2 is not None:
                picam2.stop_recording()
                picam2.close()
        except:
            pass
        Ab.stop()
